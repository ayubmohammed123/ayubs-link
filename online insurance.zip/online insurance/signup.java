import java.sql.*;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class signup extends HttpServlet
 {
PreparedStatement st=null;
Connection con=null;
public void init()
{
System.out.println("init");
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","1234");

}
catch(Exception ae)
{}
}

    public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException 
{
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
       
	String a=req.getParameter("t1");
	String b=req.getParameter("t2");
	String c=req.getParameter("t3");
	String d=req.getParameter("t4");
	String e=req.getParameter("t5");
	String f=req.getParameter("t6");
	
	 
 try 
{
int value = (int)(Math.random() *9999);
st=con.prepareStatement("insert into signup values(?,?,?,?,?,?)");
	st.setString(1,a);
	st.setString(2,b);
	st.setString(3,c);
	st.setString(4,d);
	st.setString(5,e);
	st.setString(6,f);
	st.execute();
out.println("<html>");
out.println("<body bgcolor=cyan>");
out.println("<table>");
out.println("<tr><td>");
out.println("Register no is  "+value);
out.println("</tr>");
out.println("<tr><td>");
 
out.println("</tr>");
out.println("<tr><td>");
out.println("<a href=login.html>Login</a>");
out.println("</tr>");

          
	
            out.println("</body>");
            out.println("</html>");
}
catch(Exception at)
{}
             
	
           
              } 

 
}