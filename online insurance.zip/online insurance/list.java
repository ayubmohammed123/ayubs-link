import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class list extends HttpServlet
 {
public void init()
{
System.out.println("init");
}

    public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException 
{
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
       
	String a=req.getParameter("t1");
	
	if(a.equals("Suresh"))
	res.sendRedirect("first.html");
	else if(a.equals("Pradeep"))
	res.sendRedirect("second.html");
	if(a.equals("Kiran"))
	res.sendRedirect("third.html");
	else if(a.equals("Peter"))
	res.sendRedirect("fourth.html");
	else if(a.equals("Sumeet"))
	res.sendRedirect("fifth.html");
	else 
{
	out.println("<html>");
out.println("<body bgcolor=cyan>");
out.println("<table>");
out.println("<tr><td>");
out.println("Registration is under process");
out.println("</tr>");
out.println("<tr><td>");
 
out.println("</tr>");
out.println("<tr><td>");
out.println("</tr>");

          
	
            out.println("</body>");
            out.println("</html>");
}
	
}

             
}